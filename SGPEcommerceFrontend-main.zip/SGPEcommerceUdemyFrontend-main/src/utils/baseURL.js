export const baseURL = "https://sgp-ecommerce-udemy-backend.vercel.app";

export const config = {
    headers: {
        "Content-Type": "application/json",
    },
    withCredentials: true
};